<?php

    $n= $_POST['n'];
     $a = 0;
     $b = 1;
     echo "fibonacci series is : $a $b ";
     $c = 2;
     while($c<$n){

        $sum = $a+$b;
        $a=$b;
        $b=$sum;
        echo "$sum";
        $c++;

     }
     ?>