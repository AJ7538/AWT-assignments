<?php
    $n = $_POST['n'];
    $sum = 0;
    $i=1;
    $avg;
    while($i <= $n){

        $sum = $sum + $i;
        $i++;
    }

    $avg = $sum/$n;

    echo "the sum of the first $n numbers is $sum and their average is $avg";
    
?>