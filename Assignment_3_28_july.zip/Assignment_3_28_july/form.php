<?php 
    $n = $_POST['input'];
    $choice = $_POST['choice'];
    $sqr;
    $cube;
    switch($choice){

    case 1:
    // check positive/negative
    if($n >0)
        echo "$n is positive\n";
    else {
        echo "$n is negative\n";
        $n = $n*(-1);
    }
    break;

    case 2:
    //check if even or odd

    if($n % 2 == 0)
        echo "$n is even\n";
    else
        echo"$n is odd\n";

    break;

    case 3:
    //find square

    $sqr = $n*$n;
        echo "the square of $n is $sqr\n";
        break;

    case 4:
    //find cube
    $cube = $n*$n*$n;
        echo "the cube of $n is $cube\n";
        break;
    
    default : {echo "wrong input\n";}
    }

    

        ?>
