<?php

    $num = $_POST['num'];
    $i=1;
    $fact = 1;

    for($i=1;$i<=$num;$i++){

        $fact = $fact * $i;
    }

    echo "the factorial of the number $num is $fact";