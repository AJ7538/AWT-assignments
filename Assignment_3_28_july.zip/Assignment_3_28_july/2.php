<?php
    $num = $_POST['num'];
    $rem;
    $rev=0;
    $cpy= $num;

    //logic for palindrome;

    while($num>0){
        $rem = $num % 10;
        $rev = $rev*10 + $rem;
        $num = (int) ($num/10);

    }
    if($rev ==  $cpy)
        echo "$cpy is a palindrome\n";
    else
        echo "$cpy is not a palindrome\n";

?>