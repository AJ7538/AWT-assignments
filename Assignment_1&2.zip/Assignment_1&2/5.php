<?php
    $prn=$_POST['prn'];
    $name=$_POST['name'];
    $phys=$_POST['phys'];
    $chem=$_POST['chem'];
    $maths=$_POST['maths'];
    
    $total = $phys + $chem + $maths;
    $percentage = $total/3;

    if($percentage >=40){
    echo "$name with PRN $prn has secured total $total marks and $percentage%";
    echo "Status = Pass";
    }
    else{
        echo "$name with PRN $prn has secured total $total marks and $percentage%";
        echo "Status = Fail";
    }
    ?>
