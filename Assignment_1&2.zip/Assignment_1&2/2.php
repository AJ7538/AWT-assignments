<?php
    $r=$_POST['radius'];
    define("pi", 3.142);

    $area = pi*$r*$r;
    $perimeter = 2*pi*$r;

    echo "the area is $area";
    echo "the perimeter is $perimeter";

    ?>