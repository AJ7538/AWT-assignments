<?php

    $units=$_POST['unit'];
    $charge=0;
    $total=0;
    if($units<=50){
        $charge = $units * 0.50;
    }
    else if($units>50 && $units <=150){
        $charge = $units * 0.75;
    }
    else if($units>150 && $units<=250){
        $charge = $units * 1.20;
    }
    else if($units>250){
        $charge = $units * 1.50;
}
    $total = $charge + ($charge * 0.20);
    echo "the bill total is $total";