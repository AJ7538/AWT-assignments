<?php
    $num = $_POST['num'];

    if($num % 10 == 0){
        echo "$num is divisible by 10";
        if($num % 20 ==0){
            echo "<br>$num is divisible by both 10 and 20";
        }
    else{
        echo "$num is not divisible by either 10 or 20";
    }
    }
    ?>