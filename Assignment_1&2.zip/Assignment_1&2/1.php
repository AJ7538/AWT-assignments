<?php
    $p=$_POST['principal'];
    $r=$_POST['rate'];
    $t=$_POST['time'];

    $SI=($p*$r*$t)/100;
    echo "simple interest is $SI";
    ?>