<?php
    $ch=$_POST['char'];

    if($ch == 'a' || $ch == 'e' || $ch == 'i' || $ch == 'o' || $ch == 'u'){
        echo "$ch is a vowel";
    }
    else 
    {
        echo "$ch is a consonant";
    }
    ?>
    