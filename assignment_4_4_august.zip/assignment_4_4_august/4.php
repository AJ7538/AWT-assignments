<?php
$languages = ["C", "C++", "Java", "Python", "PHP"];

// Using for loop
echo "Using for loop:<br>";
for ($i = 0; $i < count($languages); $i++) {
    echo $languages[$i] . "<br>";
}


// Using foreach loop

echo "<br>Using foreach loop:<br>";
foreach ($languages as $lang) {
    echo $lang . "<br>";
}
?>