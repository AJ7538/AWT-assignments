<?php
if (isset($_POST['submit'])) {
    $image = $_FILES['image'];
    $target = "uploads/" . basename($image['name']);

    echo "Trying to upload to: $target<br>";

    if (move_uploaded_file($image['tmp_name'], $target)) {
        echo "✅ Image uploaded successfully!";
    } else {
        echo "❌ Failed to upload image.<br>";
        echo "Error code: " . $image['error'];
    }
}
?>
